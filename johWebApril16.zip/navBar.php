<div class="navBar">
    <div class="logo"><!-- logo --></div>
    <!--nnnnnnaaavvv barrrrr hamburgerrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr-->
    <label for="toggle-menu" class="hamburger-icon">&#9776;</label>
    <button class="close-button" aria-label="Close">X</button>

    <nav class="navbar2">
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="projects.php">Projects</a></li>
            <li><a href="projects.php">Services</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </nav>


    <!--nnnnnnaaavvv barrrrr hamburgerrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr-->
    
    <div class="navLinks">
        <a href="index.html">Home</a>
        <a href="about.php">About us</a>
        <a href="projects.php">Projects</a>
        <a href="projects.php">Services</a>
        <a href="contact.php" class="contactButton">Contact us</a>
    </div>                  

</div>