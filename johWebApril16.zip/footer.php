

<div class="footer">
            <p>&copy; 2024 JRC Electric LLC. All rights reserved.</p>
        
        </div>